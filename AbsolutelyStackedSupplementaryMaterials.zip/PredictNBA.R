## ## ## ## 
  ## Use the script below to pull new NBA data, and make predictions given new data from Vegas
## ## ## ## 

rm(list = ls())
strt <- Sys.time()
setwd("")
## enter matchups
#' 1) away team,
#' 2) home team,
#' 3) spread,
#' 4) over/under
#' 5) moneyline
matchups_enter <- matrix(
  
  c(  #HomeTeam, #AwayTeam, #Spread, #Total, #MoneylineTop,MoneyLineBottom
   "UTA","PHI",-3,217,-160,135,
   "LAL","MEM",-3.5,222.5,-165,140,
   "DEN","SAS",-1,214.5,-115,-105
  ),
  byrow = T,
  ncol = 6
)
playoffs <- F

## Link To Vegas Odds
paste0(
  "https://sportsdatabase.com/nba/query?output=default&sdql=date%2C+team%2C+site%2C+o%3Ateam%2C+line%2C+total+%40date+%3D+",
  paste0(unlist(strsplit(as.character(Sys.Date()),"-")),collapse = ""),
  "+and+site+%3D+home&submit=++S+D+Q+L+%21++")
################################################################################ 
    ## ## Helper Functions ## ## 
## implied probability from moneyline
implied_prob <- function(mL){
  mL/(100 + mL)
}

# ## Gauss-Hermite Quadrature
# library(lme4)
# GHW <- lme4::GHrule(15)
# GH_std <- function(h,GHWeights){ # takes in k, number of nodes and h, your function that takes in a scalar, standard normal variable
#   sum(h(GHWeights[,1])*GHWeights[,2])
# }

# Single Metropolis Hastings Update (Grant Brown 2021)
MH_update <- function(x0, f, g, g.s, log = FALSE){
  # Multivariate version of the MH code given previously. 
  x1 <- g.s(x0)
  if(sum(names(x0) > 1)>1){
    names(x1) <- names(x0)
  }
  if (log){
    a <- (f(x1) - f(x0)) + g(x1, x0) - g(x0, x1)
    u <- log(runif(1,0,1))
  } else{
    a <- (f(x1)/f(x0))*(g(x1, x0)/g(x0, x1))
    u <- runif(1,0,1)
  }
  if (u < a){
    return(x1)
  } else{
    return(x0)
  }
}

# Metropolis Hastings Algorithm
MH <- function(n_iterations, x0, f, g, g.s, log = FALSE){
  # Should return an n*p matrix, where p is the length of x0
  M <- x0
  return(foreach(i = 1:n_iterations,
          .combine = 'rbind') %dopar% {
            MM <- try({MH_update(
              M,
              f,
              g,
              g.s,
              log)},silent = T)
            if(class(MM) != 'try-error'){
              Mprev <- M
              M <- MM
              if(any(M != Mprev)){
                M
              } else{
                invisible()
              }
            } else {
              invisible()
            }
          })
  
}

# generalizes matrix multiplication for A %*% b when the elements of matrix A and vector b are themselves conformable matrices.
# needed for making softmax predictions
`%**%` <- function(A,b){
  list <- (lapply(1:length(A),function(j){
    A[[j]] %*% b[[j]]
  }))
  sapply(1:ncol(list[[1]]),function(j){
    rowSums(sapply(list,function(l)l[,j]))
  })
}
################################################################################
  ## ## Load Data and Libraries ## 

start_algo <- Sys.time()
library(MachineShop)
library(dplyr)
library(recipes)
library(foreach)
library(doParallel)
library(purrr)
library(data.table)
library(doSNOW)
library(magrittr)
library(R.utils)
library(LaplacesDemon)
library(AbsolutelyStacked)
lag_og <- 2
library(nbastatR)
options(curl_interrupt = TRUE)
load("bs.RData")
lag <- lag_og
cutoff <- .04
matchups_og <- matchups_enter[,c(1:4)]
# read.csv('matchup_data.csv') %>%
#   rbind(matchups_enter %>%
#           as.data.frame %>% 
#           mutate(date = as.character(Sys.Date()))) %>% 
#   unique %>% 
#   write.csv(file ='matchup_data.csv',row.names = F)
matchups_og <- matchups_og %>% 
  as.data.frame(stringsAsFactors = FALSE)

  ## extract spread/over under/moneyline odds
prior_mu_spread <- as.numeric(matchups_og[,3])
prior_mu_ou <- as.numeric(matchups_og[,4])
matchups_og <- matchups_og[, c(1, 2)]
cat("\n\n\n\n\n\n\n\n\n++++++++++++++++++++++++++++++++++++\n\n\n\n\n\n\n")
################################################################################
    ## ## Load last night's data, bind it to what we have ##

load('bs.RData')
years <- 2022
gl <- game_logs(years, result_types = 'team',
                assign_to_environment = FALSE) %>%
  mutate(outcome = as.numeric(as.factor(outcomeGame))-1)
gl <- gl[!(gl$dateGame %in%  c(Sys.Date())),]
  # bind_rows(
  #   game_logs(years, result_types = 'team',
  #             assign_to_environment = FALSE,
  #             season_types = "Playoffs")
  # ) %>%
  #mutate(outcome = as.numeric(as.factor(outcomeGame))-1)
gl <- gl[order(gl$dateGame),]
gl <- gl[!is.na(gl$outcomeGame),]
ids <- unique(gl$idGame)
start <- Sys.time()
ids <- ids[!(ids %in% bs$idGame)]
ids <- ids[!(as.character(ids) %in% c("21201214"))] %>% rev

#ids <- c(22100314,22100315,22100316,22100317,22100318)
#bs <- bs[!(bs$idGame %in% ids)]
# bs <- bs[!(bs$idGame %in% c("21201214")),]
# bs <- bs[!(bs$idGame %in% ids),]
#ids <- ids[!(ids %in% bs$idGame)]
#ids <- ids[!(as.character(ids) %in% c("21201214"))] %>% rev

if(length(ids) > 0) {
  for (id in ids[1:min(length(ids),100)]) {
    print(paste(grep(id, ids), length(ids), sep = "/"))
    bs_temp <- try({
      withTimeout({
        box_scores(
          game_ids = id,
          result_types = "team",
          box_score_types = c(
            "Advanced",
            "Scoring",
            "Four Factors",
            "Misc",
            "tracking"
          ),
          assign_to_environment = FALSE
        )$dataBoxScore %>%
          as.data.frame()
      }, timeout = 11, onTimeout = "error")
    }, silent = TRUE)
    if (class(bs_temp) == "data.frame") {
      bs <- bind_rows(bs, bs_temp)
    } else{
      print("failed")
    }
    end <- Sys.time()
    print(end - start)
  }
  end <- Sys.time()
  print(end - start)
  bs <- unique(bs)
  save(bs,file = "bs.RData")
}
table(bs$slugTeam[bs$idGame %in% gl$idGame[gl$yearSeason == 2022]])
################################################################################
    ## ## Data Pre-Processing to Match What Was Trained on ## 

## Gather all data, combine into one dataframe
## take weighted averages, per 40 min, etc.
gl$before_or_after_2017 <- as.numeric(gl$yearSeason >= 2017)
gl$is_playoff_game <- as.numeric(gl$typeSeason == "Playoffs")
##
vars <- colnames(gl)[grepl("Team",colnames(gl))]
vars <- c(na.omit(vars[9:31]))
vars <- vars[!(vars %in% c("plusminusTeam",
                           "minutesTeam",
                           "outcome"))]
##
vars <- unique(c(vars))
nonpermin_vars <- c(c(vars[grep("pct",vars)]),"outcome","plusminusTeam")
non_lag_vars <- c("isB2BSecond","isB2BFirst","countDaysRestTeam","numberGameTeamSeason","before_or_after_2017","ptsTeamNextGame")
vars <- vars[-grep("pct",vars)]
##
box_vars <-
  c(
    'pctAST',
    'pctOREB',
    'pctDREB',
    'pctTREB',
    'pctTOVE',
    'pctTOVTeam',
    'pctEFG',
    'pctTS',
    'ortgE',
    'ortg',
    'drtgE',
    'drtg',
    'netrtgE',
    'netrtg',
    'ratioASTtoTOV',
    'ratioAST',
    'paceE',
    'pace',
    'pacePer40PACE_PER40',
    'possessions',
    'ratioPIE',
    'pctFGAasFG2',
    'pctFGAasFG3',
    'pctPTSasFG2',
    'pctPTSasFG2asMR',
    'pctsPTSasFG3',
    'pctPTSasFB',
    'pctPTSasFT',
    'pctPTSasOffTOV',
    'pctPTSasPaint',
    'pctFG2MasAssisted',
    'pctFG2MasUnassisted',
    'pctFG3MasAssisted',
    'pctFG3MasUnassisted',
    'pctFGMasAssisted',
    'pctFGMasUnassisted',
    'pctEFGOpponent',
    'pctTOVOpponent',
    'pctOREBOpponent',
    'rateFTA',
    'rateFTAOpponent',
    'ptsOffTOV', 
    'ptsSecondChance', 'ptsFastBreak', 
    'ptsPaint', 'ptsOffTOVOpponent', 
    'ptsSecondChanceOpponent', 'ptsFastBreakOpponent',
    'ptsPaintOpponent', 'blk', 'blka', 'pf', 'pfd', 'passes',
    'fgmContested', 'fgaContested', 'pctFGContested', 
    'fgmUncontested', 'fgaUncontested', 'pctFGUncontested', 
    'fgmRimDefended', 'fgaRimDefended', 'pctFGRimDefended', 
    'orebChances', 'drebChances', 'trebChances', 'touches', 'astSecondary', 
    'ftAST', 'ast'
  ) %>% unique
scale_box_vars <- c(   'ptsOffTOV', 
                       'ptsSecondChance', 'ptsFastBreak', 
                       'ptsPaint', 'ptsOffTOVOpponent', 
                       'ptsSecondChanceOpponent', 'ptsFastBreakOpponent',
                       'ptsPaintOpponent', 'blka','pfd', 'passes',
                       'fgmContested', 'fgaContested',  
                       'fgmUncontested', 'fgaUncontested',
                       'fgmRimDefended', 'fgaRimDefended',
                       'orebChances', 'drebChances', 'trebChances', 'touches', 'astSecondary', 
                       'ftAST')
box_vars <- box_vars[!(box_vars %in% scale_box_vars)]
box_vars <- box_vars[paste0(box_vars) %in% colnames(bs)]
scale_box_vars <- scale_box_vars[scale_box_vars %in% colnames(bs)]
start <- Sys.time()
new_gl <- data.frame()
teams <- unique(gl$nameTeam)
bs <- unique(bs)
bs$teamName[bs$teamName == "Los Angeles Clippers"] <- "LA Clippers"
gl$nameTeam[gl$nameTeam == "Los Angeles Clippers"] <- "LA Clippers"
edit_vars <- 'logpts'
average_vars <- unique(c(paste0(vars,"PerMinute"),
                         nonpermin_vars,
                         box_vars,
                         paste0(scale_box_vars,"PerMinute"),
                         edit_vars))
##
gl$logpts <- log(gl$ptsTeam)
# years <- 2021
for(year in years){
  cat("\n\t", year)
  new_gl_temp <- data.frame()
  for(team in unique(gl$nameTeam)){
    print(paste(grep(team,teams),length(teams),sep = " / "))
    data <- gl %>%
      subset((nameTeam %in% team) & (yearSeason %in% year)) %>%
      as.data.frame()
    data <- data[order(as.Date(data$dateGame),decreasing = F),]
    if(nrow(data) > 0){
      
      ## record the next games outcome for training
      #data$XXptsTeamNextGame <- as.numeric(c(data$ptsTeam[c(2:nrow(data))],NA))
      data <- scale_per_minute(data,vars)
      #data$nextOutcome <- c(data$outcome[c(2:nrow(data))],NA)
      #data$nextGameID <- c(data$idGame[c(2:nrow(data))],NA)
      #data$locationNextGame <- c(data$locationGame[c(2:nrow(data))],NA)
      #data$ptsTeamNextGame <- data$XXptsTeamNextGame
      #data$minutesNextGame <- c(data$minutes[c(2:nrow(data))],NA)
      
      bs_temp <- bs[(bs$idGame %in% data$idGame) & 
                      (bs$idTeam %in% data$idTeam),]
      colnames <- colnames(bs_temp)
      bs_temp <- scale_per_minute(bs_temp,scale_box_vars)
      if(nrow(bs_temp) > 0){
        data <- merge(data,bs_temp,by="idGame")
      } else{
        print("skip")
        next
      }
      datatemp <- data
      dataLG <- data[,colnames(data) %in% average_vars]
      for(i in 1:nrow(data)){
        for(var in average_vars){
          
          ## weighted average over all games except last one
          w <- sapply((1:max(i-1,1)),function(x)1/x)
          x <- as.numeric(unlist(data[max(i-1,1):1,var]))
          if(length(x) == 0)
          datatemp[i,var] <- weighted.mean(
            x,
            w,
            na.rm = TRUE)
          
          ## last available game's data (two games ago if NA)
          dataLG[i,var] <- as.numeric(na.omit(unlist(data[i:1,var])))[1]
        }
      }
      colnames(dataLG) <- paste0(colnames(dataLG),
                                 "LastGame")
      data <- bind_cols(datatemp,dataLG)
      if(nrow(data) < lag){
        data <- data.frame()
      }
      if(nrow(data) >= lag){
        data$year <- as.numeric(year)
        new_gl <- bind_rows(new_gl,data)
      }
    }
  }
}
end <- Sys.time()
start-end
################################################################################
    ## ## Merging Matchup Data to Pre-Processed Data ## ## 

## manually merge the next ids based on matchups
new_gl$idTeam <- new_gl$slugTeam.x ## instead of chaning bs, gl etc.
new_gl$idTeam.x %>% unique %>% sort
matchups <- matchups_og
for (i in 1:nrow(matchups)) {
  matchups$nextGameID[i] <- i
  matchups$nextGameID[i] <- i
}
matchups <- data.frame(
  "idTeam" = c(matchups$V1, matchups$V2),
  "nextGameID" = c(matchups$nextGameID, matchups$nextGameID),
  "locationGameNext" = c(rep("A", nrow(matchups)), rep("H", nrow(matchups)))
)
max_dates <- new_gl %>%
  group_by(idTeam) %>%
  summarize(max = max(dateGame)) %>%
  mutate(merge_id = paste0(idTeam, max))
new_gl$merge_id <- paste0(new_gl$idTeam,
                          new_gl$dateGame)
new_gl_dated <- new_gl %>%
  subset((merge_id %in% max_dates$merge_id) &
           (idTeam %in% matchups$idTeam))
new_gl_away <-
  new_gl_dated[new_gl_dated$idTeam %in% matchups$idTeam[matchups$locationGameNext == "A"], ]
new_gl_home <-
  new_gl_dated[new_gl_dated$idTeam %in% matchups$idTeam[matchups$locationGameNext == "H"], ]
new_gl_home <- merge(new_gl_home, matchups, by = "idTeam")
new_gl_away <- merge(new_gl_away, matchups, by = "idTeam")
new_gl_merged <- merge(new_gl_home, new_gl_away, by = "nextGameID")
new_gl_merged$idGame.x <- NULL
new_gl_merged$idGame.y <- NULL
new_gl_merged$nextOutcome <- new_gl_merged$nextOutcome.x
new_gl_merged$nextOutcome.x = new_gl_merged$nextOutcome.y = NULL

## vars to use
cols <- c(paste0(vars,"PerMinute.x"),paste0(vars,"PerMinute.y"),
          paste0(nonpermin_vars,".x"),paste0(nonpermin_vars,".y"),
          paste0(box_vars,".x"),paste0(box_vars,".y"),
          paste0(scale_box_vars,"PerMinute.x"),
          paste0(scale_box_vars,"PerMinute.y"),
          paste0(non_lag_vars,".x"),paste0(non_lag_vars,".y"),
          'logpts.x','logpts.y',
          'minutesNextGame.x',
          'year.x',
          "nextOutcome",
          "yearSeason.x",
          paste0(colnames(dataLG),".x"),
          paste0(colnames(dataLG),".y"),
          'is_playoff_game.x')
cols <- cols[!(cols %in% c(paste0(c("pctDREBLastGame",
                                    "pctOREBLastGame",
                                    "pctTREBLastGame"),
                                  ".x"),
                           paste0(c("pctDREBLastGame",
                                    "pctOREBLastGame",
                                    "pctTREBLastGame"),
                                  ".y")))]
## more cleaning
new_gl_merged$isB2BFirst.x <-
  as.numeric(factor(new_gl_merged$isB2BFirst.x)) - 1
new_gl_merged$isB2BSecond.x <-
  as.numeric(factor(new_gl_merged$isB2BFirst.x)) - 1
new_gl_merged$isB2BFirst.y <-
  as.numeric(factor(new_gl_merged$isB2BFirst.y)) - 1
new_gl_merged$isB2BSecond.y <-
  as.numeric(factor(new_gl_merged$isB2BFirst.y)) - 1
cols <- cols[cols %in% colnames(new_gl_merged)]

## final dataset prepared for prediction
df <- new_gl_merged[, cols] %>%
  apply(2, as.numeric) %>%
  as.data.frame
if (dim(df)[1] > dim(df)[2]) {
  df <- df %>% t %>% as.data.frame
}
rownames(df) <- rownames(new_gl_merged)
df$isB2BFirst.x <- as.numeric(df$isB2BFirst.x)
df$isB2BSecond.x <- as.numeric(df$isB2BFirst.x)
df$isB2BFirst.y <- as.numeric(df$isB2BFirst.y)
df$isB2BSecond.y <- as.numeric(df$isB2BSecond.y)
df_og <- df
nacols <- colnames(df[,apply(df,2,function(x)any(is.na(x)))])
print(nacols)
#df <- df[,!(colnames(df) %in% nacols)]
################################################################################

  ## make a new Z matrix to replace in the super fit for predictions w/ random intercepts
  ## quickly automates this process

predict2 <- function(fit,use_randint = T){
  Zmat <- (0*fit$super_fit$data$Zmat)[1:nrow(df),]
  if(use_randint){
    for(i in 1:nrow(matchups_og)){
      Zmat[i,paste0(c(matchups_og$V1[i],
                      matchups_og$V2[i]),"_",year)] <- 1
    }
    fit$super_fit$data$Zmat <- Zmat
  } else {
    for(i in 1:nrow(matchups_og)){
      Zmat[i,paste0(c(matchups_og$V1[i],
                      matchups_og$V2[i]),"_",year)] <- 0
    }
    fit$super_fit$data$Zmat <- Zmat
  }
  predict(fit,newdata = df,type = 'prob')
}

################################################################################

#save(fit,res, file = "super_model.RData")
rownames <- rownames(df)
df$nextOutcome <- NULL

## ## ## ##
outcome_vars <- c('logPtsGame',
                  'ptsGame',
                  'spreadDiff')
## last step; insert playoff interaction terms for all variables
for(col in colnames(df)[!(colnames(df) %in% outcome_vars)]){
  df$interaction <- df$is_playoff_game.x * as.numeric(unlist(df[[col]]))
  colnames(df)[colnames(df)=="interaction"] <- paste0("Playoffsx",
                                                      col)
}
if(playoffs){
  df$is_playoff_game <- 1
}
incl_random_efx <- T
#source('glmerAIC.R')
fixed_weights <- F
rm(bs)
rm(new_gl)
################################################################################
  ## ## Posterior-Predictive on Absolute Scale ## ## 
  
## overtime predictions
#load("fit_overtime.RData")
#load('multinomial_fit.RData')
#load('multinomial_fit.RData')
load('stack_stan_overtime.RData')
#rint <- stacked$fit$super_fit$data$final_fit$u_update
#save(rint,file = 'rint.RData')
fit_ot <- stacked$fit
stan.result_ot <- stacked$stan.result
rm(stacked)
#ot_train <- predict(fit_ot,type = 'prob')
ot_preds <- ((predict2(fit_ot,use_randint = T)))
print(ot_preds)

## pts per 48 min predictions
#load("fit_ptsGame.RData")
#load('gaussian_fit.RData')
load('stack_stan_gaussian.RData')
fit <- stacked$fit
stan.result <- stacked$stan.result
mins <- as.numeric(as.character(response(fit_ot)))
#pts <- mins/240 * response(fit)
my_preds_per48 <- as.numeric((predict2(fit)))
my_preds <- sapply(1:length(my_preds_per48),function(p){
    my_preds_per48[p]*(ot_preds[p,1]) + 
    my_preds_per48[p]*(265/240)*ot_preds[p,2] + 
    my_preds_per48[p]*(290/240)*ot_preds[p,3]
})

## Vegas's prior data on the absolute scale
load('empirical_linear_resid_pointsbet.RData') #  pts per game residuals 
vegas_resid <- resid_linear
vegas_preds <- (prior_mu_ou)


## average minutes per game
(avg_time <- sum((c(0.939992052,0.051794940,0.008213008) * c(48, (48+5), (48+10)))))
# ~ 48.324 minutes

## posterior distributions for pts-per-48 of interest
#load('stan_result_linear.RData')
load('ptsGame_stan.RData')
posterior_draws <- cbind(c(stan.result@sim$samples[[1]]$dispersion[-c(1:10000)],
                           stan.result@sim$samples[[2]]$dispersion[-c(1:10000)]),
                         c(stan.result@sim$samples[[1]]$sigmaSq_etahat[-c(1:10000)],
                           stan.result@sim$samples[[2]]$sigmaSq_etahat[-c(1:10000)]))
#posterior_draws <- posterior_draws[-c(1:(nrow(posterior_draws)/2)),]
f_y_given_eta <- function(Y,eta,dispersion){
  sum((dnorm(Y,mean = eta, sd = sqrt(dispersion),log = T)))
}
f_etahat_given_y_eta_sigmaSqhateta <- f_y_given_eta
prior_eta <- function(eta,mu0,sigmaSq0){
  sum((dnorm(eta,mean = mu0*(48/48.324), sd = sqrt(sigmaSq0)*48/48.324,log = T)))
}
sigmaSq0 <- var(vegas_resid)*(48/avg_time)^2
density_sigmaSqetahat <- cbind(density(posterior_draws[,2])$x,
                               density(posterior_draws[,2])$y)
density_dispersion <- cbind(density(posterior_draws[,1])$x,
                            density(posterior_draws[,1])$y)
closest_density <- function(v,dens){
  diff <- abs(dens[,1]-v)
  dens[,2][which(diff == min(diff))]/sum(dens[,2])
}
post_eta <- function(sigmaSq_0,
                     sigmaSq,
                     mu_0,
                     x_i,
                     eta){
  new_mu <- 1/(1/sigmaSq_0 + 1/sigmaSq) * 
    (mu_0/sigmaSq_0 + x_i/sigmaSq)
  
  new_sig <- sqrt(
    1/(1/sigmaSq_0+ 1/sigmaSq)
  )
  
  dnorm(eta,mean = new_mu, sd = new_sig,log = T)
}
cl <- makeCluster(7)
registerDoParallel(cl)
clusterExport(
  cl,
  c(
    c(lsf.str()),
    'posterior_draws',
    'my_preds',
    'vegas_preds',
    'MH_update',
    'sigmaSq0',
    'MH',
    'density_sigmaSqetahat',
    'density_dispersion',
    'ot_preds',
    'foreach',
    'post_eta'#,
    #'GH_std',
    #'GHW'
  )
)
rm(fit_ot)
post_draws <- list()
######### START MH #############
for(k in 1:length(vegas_preds)){
  print(k)
  initial_values <- c("eta" = vegas_preds[k]*(48/avg_time),
                      "Ynew" = as.numeric((my_preds_per48[k])),
                      
                      "dispersion" = sum(density_dispersion[,1]*density_dispersion[,2])/sum(density_dispersion[,2]),
                      "sigmaSq_etahat" = sum(density_sigmaSqetahat[,1]*density_sigmaSqetahat[,2])/sum(density_sigmaSqetahat[,2]))
  M <- initial_values
  result <- foreach(chain = 1:5,.combine = 'rbind') %do% {
    print("")
    res_temp <- try({(foreach(i = 1:48000,
             .combine = 'rbind') %dopar% {
               MM <- try({MH_update(
                 M,
                 f = function(x) {
                     log(closest_density(x['dispersion'],density_dispersion)) +
                     log(closest_density(x['sigmaSq_etahat'],density_sigmaSqetahat)) +
                     f_y_given_eta(x['Ynew'], x['eta'],x['dispersion']) + 
                     post_eta(sigmaSq0,
                              x['sigmaSq_etahat']+x['dispersion'], ## we add dispersion when marginalizing over Y
                              vegas_preds[k],
                              my_preds_per48[k],
                              x['eta'])
                 },
                 g = function(from,to,sd_prop = c(4,10,2,1,1)){
                   sum(log(dnorm(to,from,sd_prop)))
                 },
                 g.s = function(from,sd_prop = c(4,10,2,1,1)){
                   from + rnorm(length(from),
                                0,
                                sd_prop)
                 },
                 log = T)},silent = T)
               if(class(MM) != 'try-error'){
                 Mprev <- M
                 M <- MM
                 if(any(M != Mprev)){
                   M
                 } else{
                   invisible()
                 }
               } else {
                 M <- M + rnorm(length(M),
                                0,
                                0.01)
               }
             })},silent = T)
    if(class(res_temp) != 'try-error'){
      ## burn-in the first 4th
      res_temp <- res_temp[-c(1:(nrow(res_temp)/4)),]
      ## only select every 14th (thinning)
      res_temp[seq(1,nrow(res_temp),by = 2),]
    }
  }
  post_draws[[k]] <- result[,2]
  plot(post_draws[[k]],main = paste0("M.H. Draws for Total Points Scored per 48 Min: ",paste(matchups_enter[k,1:2],
                                                                                            collapse = " vs. "),
                                     collapse = ""))
}
stopCluster(cl)
######### END MH #############


## posterior distribution for multinomial-related outcome parameters of interest
#load('overtime_stan.RData')
#load('stack_stan_overtime.RData')
stan.result <- stan.result_ot
rm(stan.result_ot)
rm(fit_ot)
#load('stan_result_linear.RData')
#load('overtime_stan.RData')
posterior_draws <- cbind(c(stan.result@sim$samples[[1]]$sigmaSq_etahat[-c(1:250)],
                           stan.result@sim$samples[[2]]$sigmaSq_etahat[-c(1:250)]))
f_y_given_eta <- function(Y,eta,dispersion = 1){
  Y1 <- c(1-sum(Y),Y)
  eta1 <- c(1-sum(eta),eta)
  sum((ddirichlet(Y1,alpha = eta1,log = T)))
}
f_etahat_given_y_eta_sigmaSqhateta <- function(etahat,eta,sigmaSq_etahat){
  sum((dnorm(etahat,eta,sqrt(sigmaSq_etahat),log = T)))
}
prior_eta <- function(eta,mu0,sigmaSq0 = 1){
  sum((ddirichlet(eta,mean = mu0,log = T)))
}
sigmaSq0 <- 1
density_sigmaSqetahat <- cbind(density(posterior_draws[,1])$x,
                               density(posterior_draws[,1])$y)
density_dispersion <- cbind(1,1)
closest_density <- function(v,dens){
  diff <- abs(dens[,1]-v)
  dens[,2][which(diff == min(diff))]/sum(dens[,2])
}
logit <- function(x){
  log(x/(1-sum(x)))
}
softmax <- function(x){
  exp(x)/(1+sum(exp(x)))
}
cl <- makeCluster(7)
registerDoParallel(cl)

## Proof of the 1:1 transformation of softmax to logit for the K-1 simplex
# dirich <- rdirichlet(100000,alpha = c(0.939992052,0.051794940,0.008213008))
# transf_dirich <- t(apply(dirich[,-1],1,function(x)logit(x)))
# back_transf <- t(apply(transf_dirich,1,function(x)softmax(x)))
# back_transf <- cbind(1-rowSums(back_transf),back_transf)
# head(back_transf)
# head(dirich)

## manually-specify prior to be marginal NBA proportion of overtime/double-overtime
mu0_1 <- logit(c(0.051794940,0.008213008))[1]
mu0_2 <- logit(c(0.051794940,0.008213008))[2]
# 
# plot(density(transf_dirich[,1]))
# plot(density(transf_dirich[,2]))

clusterExport(
  cl,
  c(
    c(lsf.str()),
    'posterior_draws',
    'my_preds',
    'vegas_preds',
    'MH_update',
    'sigmaSq0',
    'MH',
    'density_sigmaSqetahat',
    'density_dispersion',
    'ot_preds',
    #'ot_train',
    'foreach',
    'logit',
    'softmax',
    'ddirichlet',
    'rdirichlet',
    'mu0_1',
    'mu0_2',
    'post_eta'
  )
)

######### START MH #############
post_draws_ot <- list()
for(k in 1:length(vegas_preds)){
  print(k)
  initial_values <- c("eta" = logit(c(0.051794940,0.008213008)),
                      "Ynew" = logit(c(ot_preds[k,-1])),
                      "sigmaSq_etahat" = sum(density_sigmaSqetahat[,1]*density_sigmaSqetahat[,2])/sum(density_sigmaSqetahat[,2]))
  M <- initial_values
  result <- foreach(chain = 1:5,.combine = 'rbind') %do% {
    print("")
    res_temp <- try({(foreach(i = 1:42000,
                         .combine = 'rbind') %dopar% {
                           MM <- try({MH_update(
                             M,
                             f = function(x) {
                               
                               transf_eta <- softmax(x[paste0('eta.', colnames(ot_preds)[-1])])
                               transf_y <- softmax(x[paste0('Ynew.', colnames(ot_preds)[-1])])
                               
                               dispersion <- 1
                               sigmaSq_etahat <- x['sigmaSq_etahat']
                               
                                 log(closest_density(dispersion, density_dispersion)) +
                                 log(closest_density(sigmaSq_etahat, density_sigmaSqetahat)) +
                                 f_y_given_eta(transf_y, transf_eta, dispersion) +
                                 post_eta(x['sigmaSq_etahat'],
                                          x['sigmaSq_etahat'],
                                          mu0_1,
                                          as.numeric(c(sapply(ot_preds[k, -1], logit)))[1],
                                          x[paste0('eta.', colnames(ot_preds)[2])]) +
                                 post_eta(x['sigmaSq_etahat'],
                                          x['sigmaSq_etahat'],
                                          mu0_2,
                                          as.numeric(c(sapply(ot_preds[k, -1], logit)))[2],
                                          x[paste0('eta.', colnames(ot_preds)[3])])
                                 
                                  
                             },
                             g = function(from,to,sd_prop = c(0.25,0.25,0.25,0.25,.05)){
                               sum(log(dnorm(to,from,sd_prop)))
                             },
                             g.s = function(from,sd_prop = c(0.25,0.25,0.25,0.25,.05)){
                               from + rnorm(length(from),
                                            0,
                                            sd_prop)
                             },
                             log = T)},silent = T)
                           if(class(MM) != 'try-error'){
                             Mprev <- M
                             M <- MM
                             if(any(M != Mprev)){
                               M
                             } else{
                               invisible()
                             }
                           } else {
                             M <- M + rnorm(length(M),
                                            0,
                                            0.01)
                           }
                         })},silent = T)
    if(class(res_temp) != 'try-error'){
      ## burn-in the first 4th
      res_temp <- res_temp[-c(1:(nrow(res_temp)/2)),]
      ## select every 50th (thinning)
      res_temp[seq(1,nrow(res_temp),by = 5),]
    }
  }
  ## transform the logit-scale draws to probability scale via softmax
  post_draws_ot[[k]] <- t(apply(result[, paste0("Ynew.",colnames(ot_preds)[-1])],1,softmax))
  post_draws_ot[[k]] <- cbind(c(apply(post_draws_ot[[k]],1,function(x)1-sum(x))),
                               post_draws_ot[[k]])
  layout(matrix(c(1,1,1,
                  2,2,2,
                  3,3,3),
                nrow = 3,byrow = T))
  for(numcat in 1:3){
    ## Plot it
    plot(post_draws_ot[[k]][,numcat],main = paste0(c("M.H. Draws for Probability of Regulation: ",
                                                     "M.H. Draws for Probability of Overtime: ",
                                                     "M.H. Draws for Probability of Double-Overtime: ")[numcat],paste(matchups_enter[k,1:2],
                                                                                                                                collapse = " vs. "),collapse = ""))
  }
}
stopCluster(cl)
######### END MH #############

## Calculate cum probs
cum_probs <- data.frame()
for(i in 1:length(my_preds)){
    print(i)
  
      ## points per 48 minutes
    pd_per48 <- post_draws[[i]]
      ## probability of regulation, overtime, and double ot
    ot <- post_draws_ot[[i]]
    
    ## "integrate" over empirical density of posterior-predictive for p ot
      ## regulation 
    d1 <- density(ot[,1])
    d1 <- cbind(d1$x,d1$y)
    d1[,2] <- d1[,2]/sum(d1[,2])
    
      ## single overtime 
    d2 <- density(ot[,2])
    d2 <- cbind(d2$x,d2$y)
    d2[,2] <- d2[,2]/sum(d2[,2])
    
      ## double overtime
    d3 <- density(ot[,3])
    d3 <- cbind(d3$x,d3$y)
    d3[,2] <- d3[,2]/sum(d3[,2])
    
      ## compound distribution with points per 48
    pd <- Reduce("+",lapply(1:nrow(d1),function(r){
      pd_per48*(prod(d1[r,]) + (1+5/48)*prod(d2[r,]) + (1+10/48)*prod(d3[r,]))
    }))
    dens <- density(pd)
    map <- as.numeric(dens$x[which(dens$y == max(dens$y))])
    
  temp <- cbind(
    mean(pd < vegas_preds[[i]]),
    mean(pd > vegas_preds[[i]])
  )
  cum_probs <- rbind(cum_probs,c(temp,map))
}
map <- cum_probs[,ncol(cum_probs)]
cum_probs <- cum_probs[,-ncol(cum_probs)]
colnames(cum_probs) <- c("P(mcmc < line)","P(mcmc > line)")
## P(mcmc < spread) means spread is too much in favor of home team, bet over
## P(mcmc > spread) means spread is too much in favor of away team, bet under

## mu0 how much will home team win by
## mu how much I think they will win by
## post mean: the bayesian estimate of how much they will win by
p_win <- apply(cum_probs,1,max)
p_lose <- apply(cum_probs,1,min)
bet <- ifelse(.909*p_win - 1*p_lose > .01,
              ifelse(cum_probs[,1] < cum_probs[,2],
                     "bet over",
                     "bet under"),
              "don't bet")
post_map <- map#sapply(1:length(vegas_preds),function(k)mean(post_draws[[k]]))
(absscale <- cbind(cum_probs,prior_mu_ou,my_preds,post_map,.909*p_win - 1*p_lose,bet))
################################################################################
    ## ## Posterior-Predictive on Log-Scale ## ## 

## predictions
rm(fit,result,post_draws,post_draws_ot)
#load("quasipoisson_fit.RData")
load('stack_stan_quasipoisson.RData')
fit <- stacked$fit
stan.result <- stacked$stan.result
my_preds <- as.numeric(log(predict2(fit)))
load('empirical_linear_log_pointsbet.RData') # log pts per game residuals 
vegas_resid <- resid_log
vegas_preds <- log(prior_mu_ou)
layout(matrix(1))

## posterior distributions for parameters of interest
#load('stack_stan_logPtsGame.RData')
stan.result <- stacked$stan.result
posterior_draws <- cbind(1,
                         c(stan.result@sim$samples[[1]]$sigmaSq_etahat[-c(1:2000)],
                           stan.result@sim$samples[[2]]$sigmaSq_etahat[-c(1:2000)]))
#posterior_draws <- posterior_draws[-c(1:(nrow(posterior_draws)/2)),]
#overdispersion_param <- fit$super_fit$data$final_fit$tau
overdispersion_param <- 1

  ## since we modelled y/tau where y was assumed poisson, we have to multiply back when evaluating the likelihood
  ## even though it's a 'continuous' poisson, what ever it happens to integrate to, we end up
  ## dividing out of the joint-posterior distribution anyways
  ## all we care about, is that the joint posterior is proportional to the density (on the log scale)
  ## as specified below

  ## this hack allows Metro-Hastings to be used with quasi-poisson, as Y is normally discrete and not continuous
  ## and we we can also take advantage of our dispersion parameter

  ## trust me, you get dogpoop results otherwise
f_y_given_eta <- function(Y,eta,dispersion){
  (Y*dispersion*(eta+log(dispersion)) - exp(eta)*dispersion - lfactorial(Y*dispersion))
}
f_etahat_given_y_eta_sigmaSqhateta <- function(etahat,eta,sigmaSq_etahat){
  sum((dnorm(etahat,mean = eta,sd = sqrt(sigmaSq_etahat),log = T)))
}
prior_eta <- f_etahat_given_y_eta_sigmaSqhateta
sigmaSq0 <- var(vegas_resid)
density_sigmaSqetahat <- cbind(density(posterior_draws[,2])$x,
                               density(posterior_draws[,2])$y)
density_dispersion <- cbind(1,1)
closest_density <- function(v,dens){
  diff <- abs(dens[,1]-v)
  dens[,2][which(diff == min(diff))]/sum(dens[,2])
}
cl <- makeCluster(7)
registerDoParallel(cl)
lg_tau <- log(fit$super_fit$data$final_fit$tau)
post_draws <- list()
my_preds <- my_preds - lg_tau
vegas_preds <- vegas_preds - lg_tau
tau <- exp(lg_tau)
clusterExport(
  cl,
  c(
    c(lsf.str()),
    'posterior_draws',
    'my_preds',
    'vegas_preds',
    'MH_update',
    'sigmaSq0',
    'MH',
    'density_sigmaSqetahat',
    'density_dispersion',
    'overdispersion_param',
    'lg_tau',
    'tau'
  )
)
for(k in 1:length(vegas_preds)){
  print(k)
  initial_values <- c("eta" = vegas_preds[k],
                      "Ynew" = exp(my_preds[k])/exp(lg_tau),
                      "sigmaSq_etahat" = sum(density_sigmaSqetahat[,1]*density_sigmaSqetahat[,2])/sum(density_sigmaSqetahat[,2]))
  M <- initial_values
  result <- foreach(chain = 1:5,.combine = 'rbind') %do% {
    print("")
    res_temp <- try({(foreach(i = 1:42000,
                         .combine = 'rbind') %dopar% {
                           MM <- try({MH_update(
                             M,
                             f = function(x) {
                               
                 ##
                 # sigmaSq_etahat was quantified for y/tau, not y via quasi-likelihood
                 # thus, we divide y by tau
                 # that means exp(eta) = E[Y] gets divided by tau too -> exp(eta-log(tau))
                 # and so we adjust all parameters on log scale by subtracting log-dispersion
                 # thus, the parameter sigmaSq0 actually isn't affected
                 ##        
                 #x['eta'] <- x['eta']-log(fit$super_fit$data$final_fit$tau)
                 # x['Ynew'] <- x['Ynew']/fit$super_fit$data$final_fit$tau
                 # my_pred <- my_preds[k]-lg_tau
                 # vegas_pred <- vegas_preds[k]-lg_tau
                                                  
                 my_pred <- my_preds[k]
                 vegas_pred <- vegas_preds[k]
                               
                 log(closest_density(x['sigmaSq_etahat'],density_sigmaSqetahat)) +
                 f_y_given_eta(x['Ynew'], 
                               x['eta'],
                               tau) +
                         post_eta(sigmaSq0,
                                  as.numeric(c(x['sigmaSq_etahat'])),
                                  vegas_pred,
                                  my_pred,
                                  x[paste0('eta')])
               },
               g = function(from,to,sd_prop = c(.05,10,0.00075)){
                 sum(log(dnorm(to,from,sd_prop)))
               },
               g.s = function(from,sd_prop = c(.05,10,0.00075)){
                 from + rnorm(length(from),
                             0,
                             sd_prop)
               },
               log = T)},silent = T)
                           if(class(MM) != 'try-error'){
                             Mprev <- M
                             M <- MM
                             if(any(M != Mprev)){
                               M
                             } else{
                               invisible()
                             }
                           } else {
                             M <- M + rnorm(length(M),
                                            0,
                                            0.01)
                           }
                         })},silent = T)
    if(class(res_temp) != 'try-error'){
      ## burn-in first 4th
      res_temp <- res_temp[-c(1:(nrow(res_temp)/2)),]
      ## select every 14th (thinning)
      res_temp[seq(1,nrow(res_temp),by = 2),]
    }
  }
  ## remember, we modeled y/tau when estimating sigmaSq_etaht,
  ## so now we multiply back to actually obtain y
  post_draws[[k]] <- c(result[, 2])*tau
  plot(post_draws[[k]],main = paste0("M.H. Draws for Total Points Scored: ",paste(matchups_enter[k,1:2],
                                                                                  collapse = " vs. "),
                                     collapse = ""))
}
stopCluster(cl)
my_preds <- my_preds + lg_tau
vegas_preds <- vegas_preds + lg_tau

## Calculate cum probs
cum_probs <- data.frame()
for(i in 1:length(my_preds)){
  temp <- cbind(
    mean(post_draws[[i]] < exp(vegas_preds[[i]])),
    mean(post_draws[[i]] > exp(vegas_preds[[i]]))
  )
  dens <- density(log(post_draws[[i]]))
  map <- exp(as.numeric(dens$x[which(dens$y == max(dens$y))]))
  cum_probs <- rbind(cum_probs,c(temp,map))
}
map <- cum_probs[,ncol(cum_probs)]
cum_probs <- cum_probs[,-ncol(cum_probs)]
colnames(cum_probs) <- c("P(mcmc < line)","P(mcmc > line)")
#p
## P(mcmc < spread) means spread is too much in favor of home team, bet away (top)
## P(mcmc > spread) means spread is too much in favor of away team, bet home (bottom)

## mu0 how much will home team win by
## mu how much I think they will win by
## post mean: the bayesian estimate of how much they will win by
p_win <- apply(cum_probs,1,max)
p_lose <- apply(cum_probs,1,min)
bet <- ifelse(.909*p_win - 1*p_lose > 0.01,
              ifelse(cum_probs[,1] < cum_probs[,2],
                     "bet over",
                     "bet under"),
              "don't bet")
## the 'expectation' ie sum of x * p(x)
#post_map <- (sapply(1:length(post_draws),function(i)sum(apply(post_draws[[i]],1,function(x)x[1]*x[2]))))
post_map <- map#sapply(1:length(vegas_preds),function(k)mean(post_draws[[k]])*sum(1*post_draws_ot[[k]][1] + (1+5/48)*post_draws_ot[[k]][2] + (1+5/48)*post_draws_ot[[k]][3]))
(logscale <- cbind(cum_probs,prior_mu_ou,exp(my_preds),post_map,.909*p_win - 1*p_lose,bet))
################################################################################
  ## ## Make Bet ## ## 

  ## finally....
  ## make bet when log scale and abs scale are in agreement
colnames(logscale) <- colnames(absscale)
final_bet <- cbind(absscale$bet,
                   logscale$bet) %>%
  apply(1,function(x)if(x[1] == x[2]) x[1] else "don't bet")
final <- cbind(new_gl_merged$dateGame.x,matchups_og,final_bet,absscale$my_preds,logscale$my_preds,prior_mu_ou,
               absscale$post_map,logscale$post_map,as.character(Sys.Date()))
colnames(final) <- c("Date",
                     "AwayTeam",
                     "HomeTeam",
                     "Bet",
                     "Predict Abs",
                     "Predict Log",
                     "Over/Under",
                     "Posterior Abs",
                     "Posterior Log",
                     "DateBet")

## JIC we want to analyze later
past_data <- read.csv("over_under_2022.csv")
colnames(past_data) <- colnames(final)
updated_data <- rbind(final,past_data) %>% unique

## save results
write.csv(updated_data,file = "over_under_2022.csv",row.names =F)
print(absscale)
print(logscale)

## final bet
cat("\n\n-----------------------------------------\n\n")
print(final[,-1])
nd <- Sys.time()
nd - strt


