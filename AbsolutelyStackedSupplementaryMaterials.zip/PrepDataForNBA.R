## Run this script for preparing/cleaning data for modelling purposes

library(MachineShop)
library(recipes)
library(foreach)
library(doParallel)
library(dplyr)
library(purrr)
library(data.table)
library(doSNOW)
library(magrittr)
library(R.utils)
library(MASS)
lag_og <- 2
library(nbastatR)
options(curl_interrupt = TRUE)
################################################################################ 

load('bs_playoffs.RData')
lag <- lag_og
years <- 2010:2022
## playoff games
gl <- game_logs(years[years != 2022], result_types = 'team',
                season_types = c("Playoffs"),
                assign_to_environment = FALSE) %>%
  mutate(outcome = as.numeric(as.factor(outcomeGame))-1)
gl_playoffs <- gl[order(gl$dateGame),]

## regular season games
gl <- game_logs(years, result_types = 'team',
                season_types = c("Regular Season"),
                assign_to_environment = FALSE) %>%
  mutate(outcome = as.numeric(as.factor(outcomeGame))-1)
gl_reg <- gl[order(gl$dateGame),]

## 
gl <- rbind(gl_playoffs,gl_reg)
gl <- gl[order(gl$dateGame),]
gl <- gl[!is.na(gl$outcomeGame),]
table(gl$typeSeason)

##
bs_playoff <- bs
load('bs.RData')
bs_reg <- bs
bs <- rbind(bs_reg,bs_playoff)

ids <- unique(gl$idGame)
start <- Sys.time()
ids <- ids[!(ids %in% bs$idGame)]
ids <- ids[as.character(ids) != "21201214"] %>% rev
################################################################################
## Gather all data, combine into one dataframe
## take weighted averages, per 40 min, etc.

gl$before_or_after_2017 <- as.numeric(gl$yearSeason >= 2017)
gl$is_playoff_game <- as.numeric(gl$typeSeason == "Playoffs")

##
vars <- colnames(gl)[grepl("Team",colnames(gl))]
vars <- c(na.omit(vars[9:31]))
vars <- vars[!(vars %in% c("plusminusTeam",
                           "minutesTeam",
                           "outcome"))]
vars <- unique(c(vars))
nonpermin_vars <- c(c(vars[grep("pct",vars)]),"outcome","plusminusTeam")
non_lag_vars <- c("isB2BSecond","isB2BFirst","countDaysRestTeam","numberGameTeamSeason","before_or_after_2017","ptsTeamNextGame")
vars <- vars[-grep("pct",vars)]


##
box_vars <-
  c(
    'pctAST',
    'pctOREB',
    'pctDREB',
    'pctTREB',
    'pctTOVE',
    'pctTOVTeam',
    'pctEFG',
    'pctTS',
    'ortgE',
    'ortg',
    'drtgE',
    'drtg',
    'netrtgE',
    'netrtg',
    'ratioASTtoTOV',
    'ratioAST',
    'paceE',
    'pace',
    'pacePer40PACE_PER40',
    'possessions',
    'ratioPIE',
    'pctFGAasFG2',
    'pctFGAasFG3',
    'pctPTSasFG2',
    'pctPTSasFG2asMR',
    'pctsPTSasFG3',
    'pctPTSasFB',
    'pctPTSasFT',
    'pctPTSasOffTOV',
    'pctPTSasPaint',
    'pctFG2MasAssisted',
    'pctFG2MasUnassisted',
    'pctFG3MasAssisted',
    'pctFG3MasUnassisted',
    'pctFGMasAssisted',
    'pctFGMasUnassisted',
    'pctEFGOpponent',
    'pctTOVOpponent',
    'pctOREBOpponent',
    'rateFTA',
    'rateFTAOpponent',
    'ptsOffTOV', 
    'ptsSecondChance', 'ptsFastBreak', 
    'ptsPaint', 'ptsOffTOVOpponent', 
    'ptsSecondChanceOpponent', 'ptsFastBreakOpponent',
    'ptsPaintOpponent', 'blk', 'blka', 'pf', 'pfd', 'passes',
    'fgmContested', 'fgaContested', 'pctFGContested', 
    'fgmUncontested', 'fgaUncontested', 'pctFGUncontested', 
    'fgmRimDefended', 'fgaRimDefended', 'pctFGRimDefended', 
    'orebChances', 'drebChances', 'trebChances', 'touches', 'astSecondary', 
    'ftAST', 'ast'
  ) %>% unique
scale_box_vars <- c(   'ptsOffTOV', 
                       'ptsSecondChance', 'ptsFastBreak', 
                       'ptsPaint', 'ptsOffTOVOpponent', 
                       'ptsSecondChanceOpponent', 'ptsFastBreakOpponent',
                       'ptsPaintOpponent', 'blka','pfd', 'passes',
                       'fgmContested', 'fgaContested',  
                       'fgmUncontested', 'fgaUncontested',
                       'fgmRimDefended', 'fgaRimDefended',
                       'orebChances', 'drebChances', 'trebChances', 'touches', 'astSecondary', 
                       'ftAST')
box_vars <- box_vars[!(box_vars %in% scale_box_vars)]
box_vars <- box_vars[paste0(box_vars) %in% colnames(bs)]
scale_box_vars <- scale_box_vars[scale_box_vars %in% colnames(bs)]
start <- Sys.time()
new_gl <- data.frame()
teams <- unique(gl$nameTeam)
bs <- unique(bs)
bs$teamName[bs$teamName == "Los Angeles Clippers"] <- "LA Clippers"
gl$nameTeam[gl$nameTeam == "Los Angeles Clippers"] <- "LA Clippers"

################################################################################
  
  ## For each year, each team, build up a long-form dataframe 
  ## Each entry produces 
  ##' 1) outcome information for the next game
  ##' 2) stats for the last game
  ##' 3) a weighted average of stats for past games

## Fix bug of some weird NAs, 
edit_vars <- 'logpts'
average_vars <- unique(c(paste0(vars,"PerMinute"),
                         nonpermin_vars,
                         box_vars,
                         paste0(scale_box_vars,"PerMinute"),
                         edit_vars))
##
gl$logpts <- log(gl$ptsTeam)
for(year in years){
  cat("\n\t", year)
  new_gl_temp <- data.frame()
  for(team in unique(gl$nameTeam)){
    print(paste(grep(team,teams),length(teams),sep = " / "))
    data <- gl %>%
      subset((nameTeam %in% team) & (yearSeason %in% year)) %>%
      as.data.frame()
    data <- data[order(as.Date(data$dateGame),decreasing = F),]
    if(nrow(data) > 0){
      
      ## record the next games outcome for training
      data$XXptsTeamNextGame <- as.numeric(c(data$ptsTeam[c(2:nrow(data))],NA))
      data <- scale_per_minute(data,vars)
      data$nextOutcome <- c(data$outcome[c(2:nrow(data))],NA)
      data$nextGameID <- c(data$idGame[c(2:nrow(data))],NA)
      data$locationNextGame <- c(data$locationGame[c(2:nrow(data))],NA)
      data$ptsTeamNextGame <- data$XXptsTeamNextGame
      data$minutesNextGame <- c(data$minutes[c(2:nrow(data))],NA)
      
      bs_temp <- bs[(bs$idGame %in% data$idGame) & 
                      (bs$idTeam %in% data$idTeam),]
      colnames <- colnames(bs_temp)
      bs_temp <- scale_per_minute(bs_temp,scale_box_vars)
      if(nrow(bs_temp) > 0){
        data <- merge(data,bs_temp,by="idGame")
      } else{
        print("skip")
        next
      }
      datatemp <- data
      dataLG <- data[,colnames(data) %in% average_vars]
      for(i in 1:nrow(data)){
        for(var in average_vars){
          
          ## weighted average over all games except last one
          w <- sapply((1:max(i-1,1)),function(x)1/x)
          datatemp[i,var] <- weighted.mean(
            as.numeric(unlist(data[max(i-1,1):1,var])),
            w,
            na.rm = TRUE)
          
          ## last available game's data (two games ago if NA)
          dataLG[i,var] <- as.numeric(na.omit(unlist(data[i:1,var])))[1]
        }
      }
      colnames(dataLG) <- paste0(colnames(dataLG),
                                 "LastGame")
      data <- bind_cols(datatemp,dataLG)
      if(nrow(data) < lag){
        data <- data.frame()
      }
      if(nrow(data) >= lag){
        data$year <- as.numeric(year)
        data$team <- team
        new_gl <- bind_rows(new_gl,data)
      }
    }
  }
}
end <- Sys.time()
start-end


################################################################################
  ## Choosing and preparing raw covariates for modelling

## vars to use
cols <- c(paste0(vars,"PerMinute.x"),paste0(vars,"PerMinute.y"),
          paste0(nonpermin_vars,".x"),paste0(nonpermin_vars,".y"),
          paste0(box_vars,".x"),paste0(box_vars,".y"),
          paste0(scale_box_vars,"PerMinute.x"),
          paste0(scale_box_vars,"PerMinute.y"),
          paste0(non_lag_vars,".x"),paste0(non_lag_vars,".y"),
          'logpts.x','logpts.y',
          'minutesNextGame.x',
          'year.x',
          "nextOutcome",
          "yearSeason.x",
          paste0(colnames(dataLG),".x"),
          paste0(colnames(dataLG),".y"),
          'is_playoff_game.x')

## .x is home team stats, .y is away team stats
cols <- cols[!(cols %in% c(paste0(c("pctDREBLastGame",
                                    "pctOREBLastGame",
                                    "pctTREBLastGame"),
                                  ".x"),
                           paste0(c("pctDREBLastGame",
                                    "pctOREBLastGame",
                                    "pctTREBLastGame"),
                                  ".y")))]


## merge home team/away team data
new_gl_home <- new_gl[!is.na(new_gl$nextGameID) & new_gl$locationNextGame == "H",]
new_gl_away <- new_gl[!is.na(new_gl$nextGameID) & new_gl$locationNextGame == "A",]
new_gl_merged <- merge(new_gl_home,new_gl_away,by = "nextGameID")
new_gl_merged$idGame.x <- NULL
new_gl_merged$idGame.y <- NULL
new_gl_merged$nextOutcome <- new_gl_merged$nextOutcome.x
new_gl_merged$nextOutcome.x = new_gl_merged$nextOutcome.y = NULL


## clean
new_gl_merged$isB2BFirst.x <- as.numeric(factor(new_gl_merged$isB2BFirst.x))-1
new_gl_merged$isB2BSecond.x <- as.numeric(factor(new_gl_merged$isB2BFirst.x))-1
new_gl_merged$isB2BFirst.y <- as.numeric(factor(new_gl_merged$isB2BFirst.y))-1
new_gl_merged$isB2BSecond.y <- as.numeric(factor(new_gl_merged$isB2BFirst.y))-1
nextOutcome <- cbind(new_gl_merged$nextOutcome)
rownames(new_gl_merged) <- paste0("a_",rownames(new_gl_merged))
rownames(nextOutcome) <- rownames(new_gl_merged)

new_gl_merged$ptsGame <- new_gl_merged$ptsTeamNextGame.x +
                         new_gl_merged$ptsTeamNextGame.y
new_gl_merged <- new_gl_merged[new_gl_merged$ptsGame > 25,]
################################################################################
## Construct outcomes of interest for modelling

## spread difference
new_gl_merged$spreadDiff <- 
  (new_gl_merged$ptsTeamNextGame.x) -
  (new_gl_merged$ptsTeamNextGame.y)


## overtime periods
new_gl_merged$overtime <- factor(new_gl_merged$minutesNextGame.x,
                                 levels = sort(unique(new_gl_merged$minutesNextGame.x)))
new_gl_merged$overtime[as.numeric(as.character(new_gl_merged$overtime)) > 290] <-
  290
new_gl_merged$overtime <- factor(as.character(new_gl_merged$overtime),
                                   levels  = unique(sort(new_gl_merged$overtime)))

## log pts game
new_gl_merged$logPtsGame <- log(new_gl_merged$ptsTeamNextGame.x +
                                new_gl_merged$ptsTeamNextGame.y)

## pts game per 240 min
new_gl_merged$ptsGame <- 240 * new_gl_merged$ptsGame/
                               new_gl_merged$minutesNextGame.x

## logit proportion of points scored by home team
# propPtsHomeTeam <- new_gl_merged$ptsTeamNextGame.x/(new_gl_merged$ptsTeamNextGame.x + new_gl_merged$ptsTeamNextGame.y)
# new_gl_merged$logitPropPts <- log(propPtsHomeTeam/(1-propPtsHomeTeam))


new_gl_merged$ptsGame <- 240 * new_gl_merged$ptsGame/
  new_gl_merged$minutesNextGame.x

###############################################################################
  ## Merge the final data together

rownames(new_gl_merged) <- paste(1:nrow(new_gl_merged),
                                 (paste(paste(new_gl_merged$slugTeam.x.y,
                                       new_gl_merged$year.y,sep = "_"),
                                 paste(new_gl_merged$slugTeam.x.x,
                                       new_gl_merged$year.x,sep = "_"),
                                 sep = "at")),
                                 sep = ":")
df <- new_gl_merged[,c(cols,c('logPtsGame',
                              'ptsGame',
                              'spreadDiff',
                              'overtime'))] %>%
  na.omit 
rownames <- rownames(df)

## final merge, removing nas
df <- df %>%
  apply(2,as.numeric) %>%
  as.data.frame
rownames(df) <- rownames
if(dim(df)[1] < dim(df)[2]){
  df <- df %>% t %>% as.data.frame
}
df$ptsTeamNextGame.x = df$ptsTeamNextGame.y = NULL
df <- df[df$logpts.x > -Inf & df$logpts.y > -Inf,]
if(dim(df)[1] < dim(df)[2]){
  df <- df %>% t %>% as.data.frame
}
df$ptsTeamNextGame.x = df$ptsTeamNextGame.y = NULL
df$minutesNextGame.x = NULL


## cleaning
df$isB2BFirst.x <- as.numeric(df$isB2BFirst.x)
df$isB2BSecond.x <- as.numeric(df$isB2BFirst.x)
df$isB2BFirst.y <- as.numeric(df$isB2BFirst.y)
df$isB2BSecond.y <- as.numeric(df$isB2BSecond.y)
df$nextOutcome <- NULL
df$pctUSG.x = df$pctUSG.y = NULL
df$yearSeason.x <- NULL


############################################################################### 

## ## ## ##
## these variables are the outcomes of interest we may model from this data
outcome_vars <- c('logPtsGame',
                  'ptsGame',
                  'spreadDiff',
                  'overtime')#,
                  #'logitPropPts')
save(df,outcome_vars,file = "recipes_playoffs.RData")